# Start Here

> *You were never meant to be ordinary.*

Ninety days. One arc. Three protocols a day. One honest reflection a week.

## How to use
- Open today's **Day** page each morning.
- Tick the three rituals as you complete them.
- End the day with **one line of the truth**.
- On Sundays, complete the **Weekly Reflection**.
- At Day 30, 60, and 90 — audit yourself at the gates.

## The four pillars
- **Intellect** — sharpen the blade.
- **Heart** — feel without flinching.
- **Empowerment** — master your craft.
- **Purpose** — aim at something larger than yourself.
