# Day 24 — Purpose

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

