# Day 03 — Heart

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

