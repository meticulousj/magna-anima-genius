# Day 27 — Empowerment

> **Prompt:** *What does mastery cost me this week?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

