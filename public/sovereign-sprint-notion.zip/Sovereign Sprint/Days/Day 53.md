# Day 53 — Intellect

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

