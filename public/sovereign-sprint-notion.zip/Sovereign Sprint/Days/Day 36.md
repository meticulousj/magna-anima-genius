# Day 36 — Intellect

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

