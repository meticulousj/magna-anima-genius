# Day 37 — Heart

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

