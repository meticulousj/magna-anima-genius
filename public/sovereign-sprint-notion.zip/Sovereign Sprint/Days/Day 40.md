# Day 40 — Heart

> **Prompt:** *Where have I been generous to fear?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

