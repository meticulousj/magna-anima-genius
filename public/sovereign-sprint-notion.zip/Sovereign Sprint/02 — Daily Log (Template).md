# Day __ — Pillar

> **Prompt:** _(insert today's question)_

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

