# The 90-Day Sovereign Sprint — Notion Template

A workbook by **The Magna Anima Genius Project**.

## Import
1. Open Notion.
2. Settings → **Import** → **Markdown & CSV**.
3. Drop this whole `Sovereign Sprint` folder in.
4. Notion will recreate the page tree.

Then drag `Sovereign Sprint` into your sidebar and begin with **00 — Start Here**.
