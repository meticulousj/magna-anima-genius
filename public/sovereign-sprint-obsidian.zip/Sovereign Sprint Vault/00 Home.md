# 00 Home

> *You were never meant to be ordinary.*

- [[Vision]]
- [[Milestones]]
- Daily: [[Daily/Day-01]] · [[Daily/Day-30]] · [[Daily/Day-60]] · [[Daily/Day-90]]
- Weekly: [[Weekly/Week-01]] · [[Weekly/Week-13]]

## The four pillars
- **Intellect** · **Heart** · **Empowerment** · **Purpose**
