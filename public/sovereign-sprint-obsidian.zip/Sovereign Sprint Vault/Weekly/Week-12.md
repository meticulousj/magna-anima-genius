---
week: 12
---

# Week 12 — Reflection

1. What did I prove this week?
2. Where did I flinch?
3. What pattern is repeating?
4. What will I subtract next week?
5. What will I refuse to negotiate?
