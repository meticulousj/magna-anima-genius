# 30 · 60 · 90 Milestones

## Day 30 — Gate
- What is undeniably different?
- What promise did I keep?
- What promise did I break — and why?
- What will the next thirty days demand?

## Day 60 — Gate
- (same four questions)

## Day 90 — Gate
- (same four questions)
