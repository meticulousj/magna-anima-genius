---
day: 
pillar: 
date: {{date}}
energy: 
---

# Day {{day}} — {{pillar}}

> **Prompt:**

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

