# Sovereign Sprint — Obsidian Vault

A workbook by **The Magna Anima Genius Project**.

## Open as a vault
1. Unzip this folder.
2. In Obsidian: **Open folder as vault** → select `Sovereign Sprint Vault`.
3. Start at [[00 Home]].

Templates live in `_Templates/`. Daily notes are pre-stamped in `Daily/`.
Weekly reflections live in `Weekly/`.
