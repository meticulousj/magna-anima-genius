# 90-Day Vision

## The proof I will have made
- 

## What I refuse to negotiate
- 

## What I will let go of
- 

## The one metric that matters
- 
