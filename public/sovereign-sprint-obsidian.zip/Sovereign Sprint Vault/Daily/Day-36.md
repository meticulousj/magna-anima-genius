---
day: 36
pillar: Intellect
---

# Day 36 — Intellect

[[Day-35|← Day 35]]  ·  [[00 Home|Home]]  ·  [[Day-37|Day 37 →]]

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

