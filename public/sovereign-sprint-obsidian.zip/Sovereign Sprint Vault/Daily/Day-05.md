---
day: 5
pillar: Heart
---

# Day 05 — Heart

[[Day-04|← Day 04]]  ·  [[00 Home|Home]]  ·  [[Day-06|Day 06 →]]

> **Prompt:** *Whose approval am I still chasing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

