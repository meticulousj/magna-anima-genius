---
day: 12
pillar: Heart
---

# Day 12 — Heart

[[Day-11|← Day 11]]  ·  [[00 Home|Home]]  ·  [[Day-13|Day 13 →]]

> **Prompt:** *Where have I been generous to fear?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

