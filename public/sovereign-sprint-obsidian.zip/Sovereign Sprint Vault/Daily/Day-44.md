---
day: 44
pillar: Intellect
---

# Day 44 — Intellect

[[Day-43|← Day 43]]  ·  [[00 Home|Home]]  ·  [[Day-45|Day 45 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

