---
day: 43
pillar: Purpose
---

# Day 43 — Purpose

[[Day-42|← Day 42]]  ·  [[00 Home|Home]]  ·  [[Day-44|Day 44 →]]

> **Prompt:** *What would I refuse to negotiate today, even if no one watched?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

