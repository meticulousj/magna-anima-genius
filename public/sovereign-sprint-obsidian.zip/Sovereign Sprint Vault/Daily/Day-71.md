---
day: 71
pillar: Purpose
---

# Day 71 — Purpose

[[Day-70|← Day 70]]  ·  [[00 Home|Home]]  ·  [[Day-72|Day 72 →]]

> **Prompt:** *What would I refuse to negotiate today, even if no one watched?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

