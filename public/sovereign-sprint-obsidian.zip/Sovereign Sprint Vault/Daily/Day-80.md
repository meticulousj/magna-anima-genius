---
day: 80
pillar: Purpose
---

# Day 80 — Purpose

[[Day-79|← Day 79]]  ·  [[00 Home|Home]]  ·  [[Day-81|Day 81 →]]

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

