---
day: 24
pillar: Purpose
---

# Day 24 — Purpose

[[Day-23|← Day 23]]  ·  [[00 Home|Home]]  ·  [[Day-25|Day 25 →]]

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

