---
day: 78
pillar: Intellect
---

# Day 78 — Intellect

[[Day-77|← Day 77]]  ·  [[00 Home|Home]]  ·  [[Day-79|Day 79 →]]

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

