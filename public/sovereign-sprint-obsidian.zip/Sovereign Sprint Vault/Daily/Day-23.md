---
day: 23
pillar: Heart
---

# Day 23 — Heart

[[Day-22|← Day 22]]  ·  [[00 Home|Home]]  ·  [[Day-24|Day 24 →]]

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

