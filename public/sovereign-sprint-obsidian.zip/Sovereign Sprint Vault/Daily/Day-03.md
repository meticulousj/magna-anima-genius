---
day: 3
pillar: Heart
---

# Day 03 — Heart

[[Day-02|← Day 02]]  ·  [[00 Home|Home]]  ·  [[Day-04|Day 04 →]]

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

