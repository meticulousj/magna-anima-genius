---
day: 53
pillar: Intellect
---

# Day 53 — Intellect

[[Day-52|← Day 52]]  ·  [[00 Home|Home]]  ·  [[Day-54|Day 54 →]]

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

