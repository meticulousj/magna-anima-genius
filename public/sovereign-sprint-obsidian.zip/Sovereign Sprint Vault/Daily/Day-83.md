---
day: 83
pillar: Empowerment
---

# Day 83 — Empowerment

[[Day-82|← Day 82]]  ·  [[00 Home|Home]]  ·  [[Day-84|Day 84 →]]

> **Prompt:** *What does mastery cost me this week?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

