---
day: 15
pillar: Purpose
---

# Day 15 — Purpose

[[Day-14|← Day 14]]  ·  [[00 Home|Home]]  ·  [[Day-16|Day 16 →]]

> **Prompt:** *What would I refuse to negotiate today, even if no one watched?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

