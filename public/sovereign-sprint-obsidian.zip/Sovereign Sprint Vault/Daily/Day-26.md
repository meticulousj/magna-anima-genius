---
day: 26
pillar: Heart
---

# Day 26 — Heart

[[Day-25|← Day 25]]  ·  [[00 Home|Home]]  ·  [[Day-27|Day 27 →]]

> **Prompt:** *Where have I been generous to fear?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

