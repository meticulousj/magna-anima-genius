---
day: 79
pillar: Heart
---

# Day 79 — Heart

[[Day-78|← Day 78]]  ·  [[00 Home|Home]]  ·  [[Day-80|Day 80 →]]

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

