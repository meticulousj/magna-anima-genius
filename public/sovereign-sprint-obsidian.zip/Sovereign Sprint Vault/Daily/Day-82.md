---
day: 82
pillar: Heart
---

# Day 82 — Heart

[[Day-81|← Day 81]]  ·  [[00 Home|Home]]  ·  [[Day-83|Day 83 →]]

> **Prompt:** *Where have I been generous to fear?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

