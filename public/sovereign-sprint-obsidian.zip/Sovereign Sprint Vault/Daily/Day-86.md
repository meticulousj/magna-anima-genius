---
day: 86
pillar: Intellect
---

# Day 86 — Intellect

[[Day-85|← Day 85]]  ·  [[00 Home|Home]]  ·  [[Day-87|Day 87 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

