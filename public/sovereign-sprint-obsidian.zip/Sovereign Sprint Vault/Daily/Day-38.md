---
day: 38
pillar: Purpose
---

# Day 38 — Purpose

[[Day-37|← Day 37]]  ·  [[00 Home|Home]]  ·  [[Day-39|Day 39 →]]

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

