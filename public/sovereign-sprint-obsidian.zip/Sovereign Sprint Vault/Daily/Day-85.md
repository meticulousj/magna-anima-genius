---
day: 85
pillar: Purpose
---

# Day 85 — Purpose

[[Day-84|← Day 84]]  ·  [[00 Home|Home]]  ·  [[Day-86|Day 86 →]]

> **Prompt:** *What would I refuse to negotiate today, even if no one watched?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

