---
day: 84
pillar: Intellect
---

# Day 84 — Intellect

[[Day-83|← Day 83]]  ·  [[00 Home|Home]]  ·  [[Day-85|Day 85 →]]

> **Prompt:** *Where am I confusing motion with progress?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

