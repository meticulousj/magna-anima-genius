---
day: 50
pillar: Intellect
---

# Day 50 — Intellect

[[Day-49|← Day 49]]  ·  [[00 Home|Home]]  ·  [[Day-51|Day 51 →]]

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

