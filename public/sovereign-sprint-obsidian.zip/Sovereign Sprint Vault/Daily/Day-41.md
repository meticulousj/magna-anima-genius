---
day: 41
pillar: Empowerment
---

# Day 41 — Empowerment

[[Day-40|← Day 40]]  ·  [[00 Home|Home]]  ·  [[Day-42|Day 42 →]]

> **Prompt:** *What does mastery cost me this week?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

