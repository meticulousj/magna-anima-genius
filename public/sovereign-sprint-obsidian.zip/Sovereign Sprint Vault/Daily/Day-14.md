---
day: 14
pillar: Intellect
---

# Day 14 — Intellect

[[Day-13|← Day 13]]  ·  [[00 Home|Home]]  ·  [[Day-15|Day 15 →]]

> **Prompt:** *Where am I confusing motion with progress?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

