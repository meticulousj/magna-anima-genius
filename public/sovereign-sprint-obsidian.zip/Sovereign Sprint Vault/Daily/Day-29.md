---
day: 29
pillar: Purpose
---

# Day 29 — Purpose

[[Day-28|← Day 28]]  ·  [[00 Home|Home]]  ·  [[Day-30|Day 30 →]]

> **Prompt:** *What would I refuse to negotiate today, even if no one watched?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

