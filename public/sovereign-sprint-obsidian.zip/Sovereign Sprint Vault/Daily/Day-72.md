---
day: 72
pillar: Intellect
---

# Day 72 — Intellect

[[Day-71|← Day 71]]  ·  [[00 Home|Home]]  ·  [[Day-73|Day 73 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

