---
day: 4
pillar: Empowerment
---

# Day 04 — Empowerment

[[Day-03|← Day 03]]  ·  [[00 Home|Home]]  ·  [[Day-05|Day 05 →]]

> **Prompt:** *What will my body thank me for in ten years?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

