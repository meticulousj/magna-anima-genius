---
day: 8
pillar: Intellect
---

# Day 08 — Intellect

[[Day-07|← Day 07]]  ·  [[00 Home|Home]]  ·  [[Day-09|Day 09 →]]

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

