---
day: 64
pillar: Intellect
---

# Day 64 — Intellect

[[Day-63|← Day 63]]  ·  [[00 Home|Home]]  ·  [[Day-65|Day 65 →]]

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

