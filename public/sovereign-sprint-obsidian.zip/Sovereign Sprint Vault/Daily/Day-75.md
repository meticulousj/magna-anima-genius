---
day: 75
pillar: Heart
---

# Day 75 — Heart

[[Day-74|← Day 74]]  ·  [[00 Home|Home]]  ·  [[Day-76|Day 76 →]]

> **Prompt:** *Whose approval am I still chasing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

