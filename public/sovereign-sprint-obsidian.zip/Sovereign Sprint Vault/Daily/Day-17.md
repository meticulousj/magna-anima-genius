---
day: 17
pillar: Heart
---

# Day 17 — Heart

[[Day-16|← Day 16]]  ·  [[00 Home|Home]]  ·  [[Day-18|Day 18 →]]

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

