---
day: 11
pillar: Intellect
---

# Day 11 — Intellect

[[Day-10|← Day 10]]  ·  [[00 Home|Home]]  ·  [[Day-12|Day 12 →]]

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

