---
day: 70
pillar: Intellect
---

# Day 70 — Intellect

[[Day-69|← Day 69]]  ·  [[00 Home|Home]]  ·  [[Day-71|Day 71 →]]

> **Prompt:** *Where am I confusing motion with progress?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

