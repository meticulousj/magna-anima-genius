---
day: 40
pillar: Heart
---

# Day 40 — Heart

[[Day-39|← Day 39]]  ·  [[00 Home|Home]]  ·  [[Day-41|Day 41 →]]

> **Prompt:** *Where have I been generous to fear?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

