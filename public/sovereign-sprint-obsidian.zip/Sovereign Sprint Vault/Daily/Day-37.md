---
day: 37
pillar: Heart
---

# Day 37 — Heart

[[Day-36|← Day 36]]  ·  [[00 Home|Home]]  ·  [[Day-38|Day 38 →]]

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

