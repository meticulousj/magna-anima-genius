---
day: 58
pillar: Intellect
---

# Day 58 — Intellect

[[Day-57|← Day 57]]  ·  [[00 Home|Home]]  ·  [[Day-59|Day 59 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

