---
day: 67
pillar: Intellect
---

# Day 67 — Intellect

[[Day-66|← Day 66]]  ·  [[00 Home|Home]]  ·  [[Day-68|Day 68 →]]

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

