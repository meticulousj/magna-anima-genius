---
day: 62
pillar: Purpose
---

# Day 62 — Purpose

[[Day-61|← Day 61]]  ·  [[00 Home|Home]]  ·  [[Day-63|Day 63 →]]

> **Prompt:** *What single act would make today undeniable?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

