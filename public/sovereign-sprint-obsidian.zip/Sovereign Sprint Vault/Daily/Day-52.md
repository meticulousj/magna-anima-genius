---
day: 52
pillar: Purpose
---

# Day 52 — Purpose

[[Day-51|← Day 51]]  ·  [[00 Home|Home]]  ·  [[Day-53|Day 53 →]]

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

