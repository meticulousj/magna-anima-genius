---
day: 13
pillar: Empowerment
---

# Day 13 — Empowerment

[[Day-12|← Day 12]]  ·  [[00 Home|Home]]  ·  [[Day-14|Day 14 →]]

> **Prompt:** *What does mastery cost me this week?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

