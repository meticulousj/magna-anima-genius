---
day: 10
pillar: Purpose
---

# Day 10 — Purpose

[[Day-09|← Day 09]]  ·  [[00 Home|Home]]  ·  [[Day-11|Day 11 →]]

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

