---
day: 27
pillar: Empowerment
---

# Day 27 — Empowerment

[[Day-26|← Day 26]]  ·  [[00 Home|Home]]  ·  [[Day-28|Day 28 →]]

> **Prompt:** *What does mastery cost me this week?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

