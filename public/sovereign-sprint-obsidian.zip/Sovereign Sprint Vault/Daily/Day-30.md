---
day: 30
pillar: Intellect
---

# Day 30 — Intellect

[[Day-29|← Day 29]]  ·  [[00 Home|Home]]  ·  [[Day-31|Day 31 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

