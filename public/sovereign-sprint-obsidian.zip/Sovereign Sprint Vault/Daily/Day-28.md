---
day: 28
pillar: Intellect
---

# Day 28 — Intellect

[[Day-27|← Day 27]]  ·  [[00 Home|Home]]  ·  [[Day-29|Day 29 →]]

> **Prompt:** *Where am I confusing motion with progress?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

