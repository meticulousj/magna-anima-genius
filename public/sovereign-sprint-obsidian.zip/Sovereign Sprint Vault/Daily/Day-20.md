---
day: 20
pillar: Purpose
---

# Day 20 — Purpose

[[Day-19|← Day 19]]  ·  [[00 Home|Home]]  ·  [[Day-21|Day 21 →]]

> **Prompt:** *What single act would make today undeniable?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

