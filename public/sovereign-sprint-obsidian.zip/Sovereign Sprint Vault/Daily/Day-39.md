---
day: 39
pillar: Intellect
---

# Day 39 — Intellect

[[Day-38|← Day 38]]  ·  [[00 Home|Home]]  ·  [[Day-40|Day 40 →]]

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

