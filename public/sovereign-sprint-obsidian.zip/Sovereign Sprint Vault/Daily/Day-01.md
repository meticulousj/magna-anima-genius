---
day: 1
pillar: Purpose
---

# Day 01 — Purpose

—  ·  [[00 Home|Home]]  ·  [[Day-02|Day 02 →]]

> **Prompt:** *What would I refuse to negotiate today, even if no one watched?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

