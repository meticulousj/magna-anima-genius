---
day: 66
pillar: Purpose
---

# Day 66 — Purpose

[[Day-65|← Day 65]]  ·  [[00 Home|Home]]  ·  [[Day-67|Day 67 →]]

> **Prompt:** *What is the smallest brave thing I can do now?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

