---
day: 25
pillar: Intellect
---

# Day 25 — Intellect

[[Day-24|← Day 24]]  ·  [[00 Home|Home]]  ·  [[Day-26|Day 26 →]]

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

