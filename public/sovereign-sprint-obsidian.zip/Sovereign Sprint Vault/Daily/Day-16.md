---
day: 16
pillar: Intellect
---

# Day 16 — Intellect

[[Day-15|← Day 15]]  ·  [[00 Home|Home]]  ·  [[Day-17|Day 17 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

