---
day: 87
pillar: Heart
---

# Day 87 — Heart

[[Day-86|← Day 86]]  ·  [[00 Home|Home]]  ·  [[Day-88|Day 88 →]]

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

