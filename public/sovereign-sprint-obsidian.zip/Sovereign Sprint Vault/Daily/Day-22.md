---
day: 22
pillar: Intellect
---

# Day 22 — Intellect

[[Day-21|← Day 21]]  ·  [[00 Home|Home]]  ·  [[Day-23|Day 23 →]]

> **Prompt:** *What am I tolerating that I should end?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

