---
day: 31
pillar: Heart
---

# Day 31 — Heart

[[Day-30|← Day 30]]  ·  [[00 Home|Home]]  ·  [[Day-32|Day 32 →]]

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

