---
day: 6
pillar: Purpose
---

# Day 06 — Purpose

[[Day-05|← Day 05]]  ·  [[00 Home|Home]]  ·  [[Day-07|Day 07 →]]

> **Prompt:** *What single act would make today undeniable?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

