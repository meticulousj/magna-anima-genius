---
day: 73
pillar: Heart
---

# Day 73 — Heart

[[Day-72|← Day 72]]  ·  [[00 Home|Home]]  ·  [[Day-74|Day 74 →]]

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

