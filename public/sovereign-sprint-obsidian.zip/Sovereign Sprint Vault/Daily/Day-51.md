---
day: 51
pillar: Heart
---

# Day 51 — Heart

[[Day-50|← Day 50]]  ·  [[00 Home|Home]]  ·  [[Day-52|Day 52 →]]

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

