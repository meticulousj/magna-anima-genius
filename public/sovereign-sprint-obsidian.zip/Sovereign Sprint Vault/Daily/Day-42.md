---
day: 42
pillar: Intellect
---

# Day 42 — Intellect

[[Day-41|← Day 41]]  ·  [[00 Home|Home]]  ·  [[Day-43|Day 43 →]]

> **Prompt:** *Where am I confusing motion with progress?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

