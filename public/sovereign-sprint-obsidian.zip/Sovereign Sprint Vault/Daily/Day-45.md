---
day: 45
pillar: Heart
---

# Day 45 — Heart

[[Day-44|← Day 44]]  ·  [[00 Home|Home]]  ·  [[Day-46|Day 46 →]]

> **Prompt:** *What truth have I been avoiding?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

