---
day: 65
pillar: Heart
---

# Day 65 — Heart

[[Day-64|← Day 64]]  ·  [[00 Home|Home]]  ·  [[Day-66|Day 66 →]]

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

