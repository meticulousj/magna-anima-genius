---
day: 2
pillar: Intellect
---

# Day 02 — Intellect

[[Day-01|← Day 01]]  ·  [[00 Home|Home]]  ·  [[Day-03|Day 03 →]]

> **Prompt:** *Where am I performing instead of practicing?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

