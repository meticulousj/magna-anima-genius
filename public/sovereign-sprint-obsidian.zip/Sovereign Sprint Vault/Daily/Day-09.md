---
day: 9
pillar: Heart
---

# Day 09 — Heart

[[Day-08|← Day 08]]  ·  [[00 Home|Home]]  ·  [[Day-10|Day 10 →]]

> **Prompt:** *Who do I become when no one is watching?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

