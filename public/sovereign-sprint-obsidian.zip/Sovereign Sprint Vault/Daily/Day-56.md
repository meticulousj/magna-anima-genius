---
day: 56
pillar: Intellect
---

# Day 56 — Intellect

[[Day-55|← Day 55]]  ·  [[00 Home|Home]]  ·  [[Day-57|Day 57 →]]

> **Prompt:** *Where am I confusing motion with progress?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

