---
day: 81
pillar: Intellect
---

# Day 81 — Intellect

[[Day-80|← Day 80]]  ·  [[00 Home|Home]]  ·  [[Day-82|Day 82 →]]

> **Prompt:** *What story am I telling that no longer serves me?*

## The Three
- [ ] Morning ignition
- [ ] Midday recalibration
- [ ] Evening audit

## Notes


## One line · the truth

